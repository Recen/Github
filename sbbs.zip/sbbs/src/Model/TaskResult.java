package Model;

public enum TaskResult {
	
	OK, Failed,IO_ERROR,
	
	NO_DATA,LOGIN_ERROR
	
}
