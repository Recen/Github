package utli;

import android.os.AsyncTask;

public class HotTask extends AsyncTask<Integer, Integer, String>{

	@Override
	protected String doInBackground(Integer... params) {
		// TODO Auto-generated method stub
		return null;
	}

}
